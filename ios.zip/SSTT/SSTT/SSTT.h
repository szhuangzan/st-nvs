//
//  SSTT.h
//  SSTT
//
//  Created by Duke on 11/6/14.
//  Copyright (c) 2014 DU. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SSTT : NSObject

@end
