#ifndef __ST_SERVER_H__
#define __ST_SERVER_H__



    int server();

#endif